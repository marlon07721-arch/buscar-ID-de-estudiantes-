import { buscarEstudiante } from './buscarEstudiante.js';

const divResultados = document.getElementById('resultados');

// para poner el resultado en la pagina
function mostrar(id, texto, clase) {
  const div = document.createElement('div');
  div.className = 'resultado ' + clase;

  const titulo = document.createElement('h3');
  titulo.textContent = 'Búsqueda del estudiante con ID ' + id;

  const p = document.createElement('p');
  p.textContent = texto;

  div.appendChild(titulo);
  div.appendChild(p);
  divResultados.appendChild(div);
}

function buscar(id) {
  return buscarEstudiante(id)
    .then(estudiante => {
      const texto = 'Nombre: ' + estudiante.nombre + ', Edad: ' + estudiante.edad;
      console.log(texto);
      mostrar(id, texto, 'encontrado');
    })
    .catch(error => {
      console.log('Error: ' + error);
      mostrar(id, 'Error: ' + error, 'error');
    });
}

// las hago una despues de otra para que salgan en orden
buscar(2)
  .then(() => {
    console.log('-----------------------');
    return buscar(1);
  })
  .then(() => {
    console.log('-----------------------');
    return buscar(10);
  });
