import { estudiantes } from './data.js';

// funcion que busca el estudiante y regresa una promesa
export function buscarEstudiante(id) {
  return new Promise((resolve, reject) => {
    const estudiante = estudiantes.find(est => est.id === id);

    if (estudiante) {
      resolve(estudiante);
    } else {
      reject('No existe un estudiante con el ID ' + id + '.');
    }
  });
}
